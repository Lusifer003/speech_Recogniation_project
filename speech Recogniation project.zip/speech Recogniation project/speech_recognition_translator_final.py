import time
import speech_recognition as sr
import googletrans
from googletrans import Translator
from gtts import gTTS
from playsound import playsound, PlaysoundException
import os


def speech_trans(text="", lan1=""):
    translator = Translator()
    print("Google Translator is being initiating...")
    time.sleep(0.8)
    lan2 = input("To which language are you translate:  ")
    sour_lang = lan1.lower()  # source language.
    desc_lan = lan2.lower()  # destination language.
    # --------------------------------------------
    error_flag = False
    try:
        trans_text = translator.translate(text, src=sour_lang, dest=desc_lan)
        final_text = trans_text.text
        print(f"Translation \"{lan1.capitalize()}\" to \"{lan2.capitalize()}\"...")
        print(final_text)
        # ------------------
        time.sleep(0.5)
        try:
            while True:
                listen_option = input("Are you want to listen (Y/N): ")
                if listen_option in ["y", "Y"]:
                    lang_dict = googletrans.LANGCODES
                    time.sleep(0.9)  # for better processing...
                    lang_code = lang_dict[desc_lan]
                    print(f"{desc_lan.capitalize()} language code: ", lang_code)  # /*\
                    listen = gTTS(final_text, lang=lang_code, slow=False)
                    listen.save("sample_test.aac")  # AAC for better sound quality...
                    time.sleep(0.6)
                    print("Sound is playing...")
                    playsound("sample_test.aac")  # play the save sound...
                    # os.system("sample_test.aac")  #  /*\ ...
                    print("Sound is successfully played...")
                    time.sleep(0.6)  # for better processing...
                    os.remove("sample_test.aac")  # after play the sound it will remove the sound file...
                    break
                elif listen_option in ["n", "N"]:
                    break
                else:
                    pass
                # --------------------------------------------
        except PlaysoundException:
            error_flag = True
        except KeyError:
            error_flag = True
        except Exception:
            error_flag = True
        if error_flag:
            print("There is an issue to play the sound !!!")
        # --------------------------------------------
    except ValueError:
        print("You entered a mis-spelt of language !..")
        print("\t\t\tOr,")
        print(f"\"{lan2}\" language is not supported !..")
    # --------------------------------------------


def speech_recog(trans_flag=None):
    speech = sr.Recognizer()  # Recognizer class object.
    # --------------------------------------------
    lan_list = ["Arabic", "Bengali", "English", "French", "Hindi", "Gujarati", "Punjabi", "Spanish", "Tamil", "Urdu"]
    text, language = "", ""
    choice, count = "", 0
    while True:
        print("\n\n")
        print("-----------------------------")
        print("| Initial stating position.. |")
        print("-----------------------------")
        count += 1
        if count == 1:
            choice = input("Are you able to speak now (Y/N): ")  # first time only.
        elif 1 < count < 4:
            choice = input("Do you want more time's (Y/N): ")  # second and third time.
        else:
            print("I am really glad to see you here :)")
            choice = input("Choose one (Y/N): ")  # other more than 3 times.
        if choice.lower() == 'y':
            # -------------------------------------------------
            while True:
                print("What language do you speak now ?")
                print("Supported languages: [", ", ".join(lan_list), "]")
                language = input("Type Here: ")
                language = language.capitalize()
                if language in lan_list:
                    print(f"Language selected: {language}")
                    break
                else:
                    print(f"Oops! \"{language}\" language is not supported !..\n")
                    time.sleep(0.6)
            # -------------------------------------------------
            time.sleep(0.5)
            # --------------------------------------------
            print(f"Speak now in {language} !..")
            time.sleep(0.5)
            # --------------------------------------------
            # Variables to keep track of speech detection
            speech_detected = False
            attempts = 3  # Maximum 3 attempts it tries..
            # --------------------------------------------
            try:
                with sr.Microphone() as source:
                    while not speech_detected and attempts > 0:
                        speech.adjust_for_ambient_noise(source)
                        speech.pause_threshold = 1
                        speech.energy_threshold = 600
                        error_flag = False  # For inner multiple except block...
                        try:
                            print("I am listening...")
                            # >> Maximum time length: 15 seconds., and Maximum staring timeout: 5 seconds...
                            # print(speech.energy_threshold)  # ??? /*\
                            voice_data = speech.listen(source, phrase_time_limit=15, timeout=5)
                            print("Voice recognition initializing...")
                            if language == "Arabic":
                                text = speech.recognize_google(voice_data, language='ar-EG')  # For Arabic...
                            elif language == "Bengali":
                                text = speech.recognize_google(voice_data, language='bn-BD')  # For Bengali...
                            elif language == "English":
                                text = speech.recognize_google(voice_data, language='en-US')  # For English...
                            elif language == "French":
                                text = speech.recognize_google(voice_data, language='fr-CA')  # For French...
                            elif language == "Hindi":
                                text = speech.recognize_google(voice_data, language='hi-IN')  # For Hindi...
                            elif language == "Gujarati":
                                text = speech.recognize_google(voice_data, language='gu-IN')  # For Gujarati...
                            elif language == "Punjabi":
                                text = speech.recognize_google(voice_data, language='pa-Guru-IN')  # For Punjabi...
                            elif language == "Spanish":
                                text = speech.recognize_google(voice_data, language='es-ES')  # For Spanish...
                            elif language == "Tamil":
                                text = speech.recognize_google(voice_data, language='ta-IN')  # For Tamil...
                            else:
                                text = speech.recognize_google(voice_data, language='ur-PK')  # For Urdu...
                            # --------------------------------------------
                            speech_detected = True  # Break the loop if speech is recognized
                        # --------------------------------------------
                        except sr.UnknownValueError:
                            error_flag = True
                        except sr.WaitTimeoutError:
                            error_flag = True
                        except Exception:
                            error_flag = True
                        if error_flag:
                            attempts -= 1
                            print("No Voice Coming...")
                            time.sleep(0.5)  # For better recognizing if there is no voice coming...
                            if attempts == 0:
                                print("--------------------------------------------")
                                print("It seems like, there having an issue with your audio source device !..")
                                print("Check your microphone properly !..")
                                print("--------------------------------------------")
                # --------------------------------------------
                if speech_detected:
                    print("Stop now !..")
                    time.sleep(0.8)
                    print("Voice successfully recognized...")
            # --------------------------------------------
            except sr.RequestError:
                time.sleep(0.8)
                print("--------------------------------------------")
                print("Voice Can't Be Recognized...")
                print("There was an issue with the Google recognizer.")
                print("Please check your internet connection and try again!")
                print("--------------------------------------------")
            # --------------------------------------------
            if text != "":
                print(f"Your text is now ready in {language}...")
                time.sleep(0.8)
                print(text)
                print("--------------------------------------------")
                if trans_flag:
                    time.sleep(0.5)
                    speech_trans(text, language)
                    print("--------------------------------------------")
            # --------------------------------------------
            text, language = "", ""  # remove the existing text, and also remove the existing language which is selected...
            time.sleep(3)  # wait for 3 seconds for asking next recognition time...
            # --------------------------------------------
        elif choice.lower() == 'n':
            break
            # --------------------------------------------
        else:
            print("Invalid choice. Please enter 'Y' or 'N'.")


if __name__ == "__main__":
    while True:
        print("Would you like to use this engine as :")
        print("[ Speech Recognition Only ! ], then type: 0")
        print("[ Speech Recognition and Translator also ], then type: 1")
        str_option = input("Enter: ")
        if str_option in ["0", "1"]:
            break
    # --------------------------------------------
    if str_option == "0":
        speech_recog(False)  # Speech recognition only...
    else:
        speech_recog(True)  # Speech recognition and Translator...
    # --------------------------------------------
