import time
import speech_recognition as sr
import googletrans
from googletrans import Translator
from gtts import gTTS
from playsound import playsound, PlaysoundException
import os
import requests
import pyttsx3


def check_internet():
    url = "http://www.google.com/"
    try:
        requests.get(url, timeout=1)  # requesting URL
        print("\n")
        print("--------------------------------------------")
        print("Internet connection successfully detected...")
        print("--------------------------------------------")
        engine.say("Internet connection successfully detected")
        engine.runAndWait()
        time.sleep(0.5)  # for better internet stability..
        return True
    except (requests.ConnectionError, requests.Timeout):
        print("\n")
        print("--------------------------------------------")
        print("Your internet connection is off !!!")
        print("Please check your internet connection !..")
        print("--------------------------------------------")
        engine.say("Your internet connection is off")
        time.sleep(0.2)
        engine.say("Please check your internet connection")
        engine.runAndWait()
        return False


def speak(text, lang):
    try:
        while True:
            listen_option = input("Are you want to listen (Y/N): ")
            if listen_option in ["y", "Y"]:
                lang_dict = googletrans.LANGCODES
                lang_code = lang_dict[lang]
                # print(f"{lang.capitalize()} language code: ", lang_code)  # /*\
                listen = gTTS(text, lang=lang_code, slow=False)
                time.sleep(0.4)  # for better processing...
                listen.save("project.aac")  # AAC for better sound quality...
                time.sleep(0.5)
                print("Sound is playing...")
                playsound("project.aac")  # play the save sound...
                # os.system("project.aac")  #  /*\ ...
                print("Sound successfully played...")
                time.sleep(0.6)  # for better processing...
                os.remove("project.aac")  # after play the sound it will remove the sound file...
                print("------------------------------------------")
                return
            elif listen_option in ["n", "N"]:
                print("------------------------------------------")
                break
            else:
                print("Invalid choice.")
                print("Please enter 'Y' or 'N'.")
            # --------------------------------------------
    except (PlaysoundException, KeyError, Exception):
        print("--------------------------------------------------")
        print(f"The \'{lang.capitalize()}\' language is not ready for speak !!!")
        print("--------------------------------------------------")
        time.sleep(0.5)
        engine.say(f"The {lang} language is not ready for speak")
        engine.runAndWait()
        time.sleep(0.4)
        # --------------------------------------------


def speech_trans(text="", lan1=""):
    trans_error_count = False
    max_attempts = 3
    translator = Translator()
    print("Translator is being Initializing...")
    engine.say("Translator is being Initializing")
    engine.runAndWait()
    time.sleep(0.4)
    while True:
        if max_attempts == 0:
            print("-----------------------------------------------")
            print("You have crossed all the correction limits !!!")
            print("So, The translator has been closed.")
            print("-----------------------------------------------")
            time.sleep(0.5)
            engine.say("You have crossed all the correction limits.")
            time.sleep(0.2)
            engine.say("So, The translator has been closed.")
            engine.runAndWait()
            time.sleep(0.4)
            break
        if trans_error_count:
            print("-----------------------------------")
            print(f"You have {max_attempts} wrong attempts left !!!")
            print("-----------------------------------")
            print()
            time.sleep(0.5)
            engine.say(f"You have {max_attempts} wrong attempts left")
            engine.runAndWait()
            time.sleep(0.8)
            max_attempts -= 1
            lan2 = input("Enter the correct exist translation language: ")
        else:
            lan2 = input("To which language are you translate (type any language):  ")

        sour_lang = lan1.lower()  # source language.
        desc_lan = lan2.lower()  # destination language.
        # --------------------------------------------
        try:
            trans_text = translator.translate(text, src=sour_lang, dest=desc_lan)
            final_text = trans_text.text
            time.sleep(0.8)
            print("Translator successfully translated...")
            engine.say("Translator successfully translated")
            engine.runAndWait()
            time.sleep(0.5)
            print(final_text)
            # ------------------
            time.sleep(0.5)
            speak(final_text, desc_lan)
            time.sleep(0.5)
            return
            # --------------------------------------------
        except ValueError:
            trans_error_count = True
            print()
            print("------------------------------------------")
            print("You entered a misspelt words !..")
            print("\t\tOr,")  # tab problem in exe format..
            print(f"This \'{lan2}\' language is non exist !..")
            print("------------------------------------------")
            print()
            engine.say("You entered a misspelt words")
            time.sleep(0.2)
            engine.say("Or")
            time.sleep(0.2)
            engine.say(f"This {lan2} language is non exist")
            engine.runAndWait()
            time.sleep(0.4)
            lan2 = sour_lang = desc_lan = ""
    # --------------------------------------------


def speech_recog(trans_flag=None):
    speech = sr.Recognizer()  # Recognizer class object.
    ini_count = 0
    # --------------------------------------------
    lang_dict = {"Albanian": "sq-AL", "Amharic": "am-ET", "Arabic": "ar-SA", "Armenian": "hy-AM",
                 "Azerbaijani": "az-AZ", "Basque": "eu-ES", "Bengali": "bn-BD", "Bosnian": "bs-BA",
                 "Bulgarian": "bg-BG", "Burmese": "my-MM", "Catalan": "ca-ES", "Chinese": "cmn-Hans-CN",
                 "Croatian": "hr-HR", "Czech": "cs-CZ", "Danish": "da-DK", "Dutch": "nl-NL",
                 "English": "en-US", "Estonian": "et-EE", "Filipino": "fil-PH", "Finnish": "fi-FI",
                 "French": "fr-FR", "Galician": "gl-ES", "Georgian": "ka-GE", "German": "de-DE",
                 "Greek": "el-GR", "Gujarati": "gu-IN", "Hebrew": "iw-lL", "Hindi": "hi-IN",
                 "Hungarian": "hu-HU", "Icelandic ": "is-IS", "Indonesian": "id-ID", "Italian": "it-IT",
                 "Japanese": "ja-JP", "Javanese": "jv-ID", "Kannada": "kn-IN", "Kazakh": "kk-KZ",
                 "Khmer": "km-KH", "Korean": "ko-KR", "Lao": "lo-LA", "Latvian": "lv-LV", "Lithuanian": "lt-LT",
                 "Macedonian": "mk-MK", "Malay": "ms-MY", "Malayalam": "ml-IN", "Marathi": "mr-IN",
                 "Mongolian": "mn-MN", "Nepali": "ne-NP", "Norwegian Bokmål": "no-NO", "Persian": "fa-IR",
                 "Polish": "pl-PL", "Portuguese": "pt-BR", "Punjabi": "pa-Guru-IN", "Romanian": "ru-RU",
                 "Kinyarwanda": "rw-RW", "Serbian": "sr-RS", "Sinhala": "si-LK", "Slovak": "sk-SK",
                 "Slovenian": "sl-SL", "Swati": "ss-latn-za", "Southern Sotho": "st-ZA", "Spanish": "es-ES",
                 "Sundanese": "su-ID", "Swahili": "sw-TZ", "Swedish": "sv-SE", "Tamil": "ta-IN",
                 "Telegu": "te-IN", "Thai": "th-TH", "Setswana": "tn-latn-za", "Turkish": "tr-TR",
                 "Tsonga": "ts-ZA", "Ukrainian": "uk-UA", "Urdu": "ur-PK", "Uzbek": "uz-UZ", "Venda": "ve-ZA",
                 "Vietnamese": "vi-VN", "isiXhosa": "xh-ZA", "Zulu": "zu-ZA"}
    text, language = "", ""
    choice, count = "", 0
    lang_error_count = False
    max_attempts = 5
    lang_coun_code = ""
    while True:
        ini_count += 1
        print("\n")
        print("--------------------------------")
        print("*** Initial stating position ***")
        print(f"*** Attempt to used {ini_count} times ***")
        print("--------------------------------")
        print("\n")
        engine.say("Initial stating position")
        time.sleep(0.2)
        engine.say(f"Attempt to used {ini_count} times")
        engine.runAndWait()
        # ----------------------------------------
        count += 1
        print("------------------------------------------")
        if count == 1:
            choice = input("Are you able to speak now (Y/N): ")  # first time only.
        elif 1 < count < 4:
            choice = input("Do you want speak more time's (Y/N): ")  # second and third time.
        else:
            print("I am really glad to see you again :)")
            engine.say("I am really glad to see you again")
            engine.runAndWait()
            choice = input("Select one for further decision (Y/N): ")  # other more than 3 times.
        if choice.lower() == 'y':
            # -------------------------------------------------
            while True:
                if max_attempts == 0:
                    print("-----------------------------------------------")
                    print("You have crossed all the correction limits !!!")
                    print("So, the speech recognition has closed.")
                    print("-----------------------------------------------")
                    time.sleep(0.5)
                    engine.say("You have crossed all the correction limits")
                    time.sleep(0.2)
                    engine.say("So, the speech recognition has closed")
                    engine.runAndWait()
                    time.sleep(0.4)
                    return  # if occurred, then end the function here.

                if lang_error_count:
                    print("----------------------------------")
                    print(f"You have {max_attempts} wrong attempts left !!!")
                    print("----------------------------------")
                    print()
                    time.sleep(0.5)
                    engine.say(f"You have {max_attempts} wrong attempts left")
                    engine.runAndWait()
                    time.sleep(0.8)
                    max_attempts -= 1
                    language = input("Enter the current exist language: ")
                else:
                    language = input("What language do you speak (type any language): ")
                # -------------------------------
                language = language.capitalize()
                # -------------------------------
                try:
                    lang_coun_code = lang_dict[language]  # just checking the language is presents in the dictionary or not.
                    time.sleep(0.5)
                    lang_error_count = False
                    max_attempts = 5
                    break
                except (KeyError, ValueError, Exception):
                    lang_error_count = True
                    print()
                    print("-------------------------------------------------------")
                    print(f"Oops! This \'{language}\' language is not found or exist !!!")
                    print("-------------------------------------------------------")
                    print()
                    time.sleep(0.5)
                    engine.say(f"Oops! This \'{language}\' language is not found or exist")
                    engine.runAndWait()
                    time.sleep(0.4)
                    language = ""
            # --------------------------------------------
            time.sleep(0.5)
            # --------------------------------------------
            # Variables to keep track of speech detection
            speech_detected = False
            attempts = 3  # Maximum 3 attempts it tries..
            # --------------------------------------------
            try:
                with sr.Microphone() as source:
                    print(f"Speak now in \'{language}\' language!..")
                    engine.say(f"Speak now in {language} language")
                    engine.runAndWait()
                    time.sleep(0.4)
                    while not speech_detected and attempts > 0:
                        speech.adjust_for_ambient_noise(source)
                        speech.pause_threshold = 1
                        speech.energy_threshold = 600
                        try:
                            print("listening $..")
                            # print(speech.energy_threshold)  # ??? /*\
                            # >> Maximum time length: 30 seconds., and Maximum staring timeout: 5 seconds...
                            voice_data = speech.listen(source, phrase_time_limit=30, timeout=5)
                            print("Speech Recognition Initializing...")
                            engine.say("Speech Recognition Initializing")
                            engine.runAndWait()
                            text = speech.recognize_google(voice_data, language=lang_coun_code)  # For all valid exist language.
                            # --------------------------------------------
                            speech_detected = True  # Break the loop if speech is recognized
                        # --------------------------------------------
                        except (sr.UnknownValueError, sr.WaitTimeoutError):
                            attempts -= 1
                            print("No Voice Coming...")
                            engine.say("no voice coming")
                            engine.runAndWait()
                            time.sleep(1)  # For better recognizing if there is no voice coming...
                            if attempts == 0:
                                print("----------------------------------------------------------------------")
                                print("It seems like, there having an issue with your audio source device !!!")
                                print("Check your microphone properly !..")
                                print("----------------------------------------------------------------------")
                                engine.say("It seems like, there having an issue with your audio source device")
                                time.sleep(0.2)
                                engine.say("Check your microphone properly")
                                engine.runAndWait()
                                time.sleep(0.4)
                # --------------------------------------------
                if speech_detected:
                    print("Stop now !..")
                    print("Speech detected...")
                    time.sleep(0.6)
            # --------------------------------------------
            except sr.RequestError:
                time.sleep(0.8)
                print("-------------------------------------------------")
                print("Speech Can't Be Recognized !!!")
                print("There was an issue with the Google Recognizer !..")
                print("-------------------------------------------------")
                engine.say("Speech Can't Be Recognized")
                time.sleep(0.2)
                engine.say("There was an issue with the Google Recognizer")
                engine.runAndWait()
                time.sleep(0.4)
            # --------------------------------------------
            if text != "":
                print("Speech Successfully Recognized...")
                engine.say("Speech Successfully Recognized")
                engine.runAndWait()
                time.sleep(0.4)
                print(f"Your speech is now ready in \'{language}\' language...")
                time.sleep(0.5)
                print(text)
                # ------------------
                time.sleep(0.5)
                speak(text, language.lower())
                time.sleep(0.5)
                if trans_flag:
                    time.sleep(2)
                    speech_trans(text, language)
            # --------------------------------------------
            text = language = lang_coun_code = ""  # remove the existing text, remove the existing language and the language short name with country short name.
            time.sleep(3)  # wait for 3 seconds for asking next recognition time...
        # --------------------------------------------
        elif choice.lower() == 'n':
            break
            # --------------------------------------------
        else:
            print("Invalid choice.")
            print("Please enter 'Y' or 'N'.")


if __name__ == "__main__":
    engine = pyttsx3.init()  # object creation
    engine.setProperty('rate', 140)
    engine.runAndWait()  # Pause the engine briefly to apply the changes
    voice_rate = engine.getProperty('rate')
    engine.setProperty('volume', 1)
    engine.runAndWait()  # Pause the engine briefly to apply the changes
    voices = engine.getProperty('voices')
    # engine.setProperty('voice', voices[0].id)  # for male voice.
    engine.setProperty('voice', voices[1].id)  # for female voice.
    engine.runAndWait()  # Pause the engine briefly to apply the changes
    # ---------------------------------------------------------------------
    print("\n")
    print("---------------------------------------------------")
    print("Attention: Internet Connection Required Mandatory !")
    print("---------------------------------------------------")
    print("\n")
    engine.say("Attention: Internet Connection Required Mandatory")
    engine.runAndWait()
    time.sleep(0.6)  # for proper attention viewing...
    while True:
        print("Would you like to used engine as :")
        print("[ Speech Recognition Only ], then press: 0")
        print("[ Speech Recognition Along With Translator ], then press: 1")
        str_option = input("Enter: ")
        if str_option in ["0", "1"]:
            break
        else:
            print("Oops! Invalid Selection, Press Carefully.")
            engine.say("Oops! Invalid Selection, Press Carefully")
            engine.runAndWait()
            print("\n")
    # --------------------------------------------
    time.sleep(0.5)
    if check_internet():  # if internet is connected, then it works successfully, otherwise nope !..
        if str_option == "0":
            speech_recog(False)  # Speech recognition only...
        else:
            speech_recog(True)  # Speech recognition and Translator...
    # --------------------------------------------y
    time.sleep(0.5)
    print("Engine has stopped !..")
    engine.say("Engine has stopped")
    engine.runAndWait()
    time.sleep(4)  # for properly view...
    engine.stop()  # Stop the engine
    # --------------------------------------------

